# Flax Android GitHub Probe

This is a **separate, non-destructive feasibility probe** for Roma Battle Royale.
It does not contain or modify the Godot project.

## What this first probe checks

- Can a free GitHub Actions Linux runner provision Java, .NET, Android SDK and NDK?
- Can the runner install the .NET Android workload?
- Does the toolchain report the expected versions?

**Important:** this is a prerequisite/toolchain test, not yet a Flax game build or APK.
Flax's Android cooker still needs a Flax project and a supported headless cooking/build path.
Do not treat a green run here as proof that an APK can be produced.

## How to use it from Android

1. Create a **new, separate public GitHub repository** (for example `Roma-Flax-Android-Probe`).
2. Upload the contents of this ZIP into that new repository, keeping the `.github/workflows` folder.
3. Open the repository's **Actions** tab.
4. Select **Flax Android toolchain probe**, then **Run workflow**.
5. Open the run and check the final summary and logs.

The workflow runs only when manually started. It does not run on the Godot repository.
No secrets, passwords, Unity/Flax license keys, or paid runners are required for this first check.

## Next gate

If the toolchain check passes, the next task is to prove that Flax can cook a minimal game project
to Android ARM64 in CI. That is a separate test and must not be confused with this one.
